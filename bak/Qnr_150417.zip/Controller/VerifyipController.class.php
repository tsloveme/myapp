<?php
namespace Qnr\Controller;
use Think\Controller;
class VeryfyipController extends Controller {
    //首页
	public function index(){
		$id = $_POST['id'];
		
    }
	
}