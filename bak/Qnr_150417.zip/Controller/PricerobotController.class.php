<?php
namespace Qnr\Controller;
use Think\Controller;
class PricerobotController extends Controller {
	public function index(){;
		$this->show("it works!");
    }
	/*
	* 
	*
	*
	*
	*/
	public function go(){
		$
		
	}
}



















